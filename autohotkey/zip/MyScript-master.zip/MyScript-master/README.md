# MyScript

��Ҫ�������µĽű����ο��Ľű�̫�࣬������ű�û���г�����Ϊ����ԭ�����Ӳ�һ����Ч��  

1.Drag and Drop Auto-Renamer -------by DTY  
http://www.autohotkey.com/forum/topic30647.html  

2.ע�����λ -------by yonken  

3.launcher -------alongside  
http://hi.baidu.com/alongside/blog/item/1a25ed00b4156f10738b65cb.html  

4.AHK Media Player -------Fry  
http://www.autohotkey.com/forum/topic31188.html  

5.Directory Menu -------compuboy_r  
http://www.autohotkey.com/forum/topic772.html  

6.Traycut - system tray shortcuts utility -------meter  
http://www.autohotkey.com/forum/topic15241.html  

7.Window Hider - Make windows behave like a taskbar -------loop  
http://www.autohotkey.com/forum/topic12496.html  

8.ALT-TAB REPLACEMENT -------evl  
http://www.autohotkey.com/forum/viewtopic.php?t=6422  

9.AddGraphicButton ------- corrupt  
http://www.autohotkey.com/forum/viewtopic.php?t=4047  

3 State Graphic Button (Up, Down, Hover)-------kdoske  
https://autohotkey.com/board/topic/55034-function-3-state-graphic-button-up-down-hover/  

10.FadeIn and Out -------Adde_P  
http://www.autohotkey.com/forum/viewtopic.php?t=27316  

11.Folder Menu -------rexx  
http://www.autohotkey.com/forum/topic14641.html  

12.create new folder  
http://www.autohotkey.com/forum/viewtopic.php?t=2107  

13.WinMouse.ahk  
http://www.autohotkey.com/forum/viewtopic.php?t=39906  
https://autohotkey.com/board/topic/36620-winmouse-move-windows-using-your-mouse/  

14.winpad 1.14.ahk  
http://www.autohotkey.com/forum/viewtopic.php?t=21703  
https://autohotkey.com/board/topic/19990-windowpad-window-moving-tool/  

15.FSB - Fast Screenshot Bundle  
http://www.autohotkey.com/forum/topic35580.html  

16.Screen Capture with Transparent Windows and Mouse Cursor  
http://www.autohotkey.com/forum/topic18146.html  

17.Ahk�ű�������-------����Сѩ  
http://wwww.snow518.cn  

18.Hi, Eddy--------------Eddy  
http://www.hieddy.com/  

19.����������----------------JSLover  
http://jslover.secsrv.net/AutoHotkey/Scripts/Rename-Manager.ahk  

20.F1���޸��ļ�������չ�����ļ�ʱ��----------dule2859  
http://ahkcn.net/thread-881.html

21.WinExplorer auto-search---------------Buddy  
http://www.autohotkey.com/forum/topic41463.html  

22.NiftyWindows  
http://svn.motlin.com/dev/ahk/NiftyWindows.ahk  

23.Run AHK scripts with less (half or even less) memory usage---------------heresy  
http://www.autohotkey.com/forum/topic32876.html  

24.����ĳ����������� - Pin2Desk-------------------------------BLooM2  
http://ahkcn.net/thread-1456.html

25.һ���򿪵�ǰ����ڵ�����Ŀ¼-------------------���곯ϼ  
http://ahkcn.net/thread-1709.html

26.GetModuleFileNameEx--------shimanov  
http://www.autohotkey.com/forum/topic4182-15.html  
http://www.autohotkey.com/forum/topic9000.html  

27.��ͼ�ű�-------------  
http://www.autohotkey.com/forum/topic18146.html  
http://ahk.5d6d.com/thread-2220-1-2.html  

28.Auto-raise and Other Stuff on Mouse Hover -----------------Lexikos  
http://www.autohotkey.com/forum/topic22763.html  

29.ģ�� QT TabBar ��������ѭ���任ѡ����-------------------Jameson  
http://ahkcn.net/thread-623.html

30.7plus--------------------fragman  
http://code.google.com/p/7plus/  
https://github.com/7plus/7plus  

31.JowAlert.ahk---------------wz520  
http://ahkcn.net/thread-802.html

32.Run Dynamic Script... Through a Pipe!----------------Lexikos  
http://www.autohotkey.com/forum/topic25867.html  

33.Candy--------------aamii  
https://github.com/aamii/Candy  

34.#include ��������--------------feiyue  
http://ahkcn.net/thread-6003.html  

35.LV_ColorInitiate  
https://autohotkey.com/board/topic/8463-listview-colors-for-individual-lines-eg-highlighting/  

36.OnMessageEx  
https://sites.google.com/site/ahkref/custom-functions/onmessageex  
https://autohotkey.com/board/topic/73303-onmessageex/  

37.FlashTrayIcon  
https://autohotkey.com/boards/viewtopic.php?t=4425  

38.JEE_NotepadGetPath--------------jeeswg  
https://autohotkey.com/boards/viewtopic.php?f=6&t=30050  

39.VDLink | Win7 Ŀ¼���ӹ���  
http://www.cnblogs.com/easysky/p/4931042.html  

40.RunZ | רҵ�Ŀ�����������  
https://github.com/goreliu/runz  

41.COM.ahk,VA.ahk,Gdip.ahk �ȵ�  

42.AHKhttp  
https://github.com/zhamlin/AHKhttp  

43.AHKsock  
https://github.com/jleb/AHKsock  

44.Media-Remote-Control  
https://github.com/sunwind/Media-Remote-Control  
https://autohotkey.com/boards/viewtopic.php?f=6&t=32336  
