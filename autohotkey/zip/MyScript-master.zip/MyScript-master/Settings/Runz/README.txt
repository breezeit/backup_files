﻿此目录文件说明：

RunZ.ini.help.txt
主配置 RunZ.ini 的帮助文件，当 RunZ.ini 不存在时，它会被复制成 RunZ.ini。

RunZ.ini
主配置文件，配置需要手动修改，程序不会自动写入。

UserFunctions.ahk.help.txt
用户函数帮助文件，不生效，仅供参考。手动将其复制为 UserFunctions.ahk 可生效。

UserFunctions.ahk
用户函数文件，该文件需要手动修改，程序不会自动写入，修改前请仔细阅读文件中的说明。

UserFunctionsAuto.txt.template
发送到菜单写入的配置模版，请不要修改此文件。
如果打开了发送到菜单功能，并且无 UserFunctionsAuto.txt 文件，改文件会被复制为 UserFunctionsAuto.txt。

UserFunctionsAuto.txt
发送到菜单写入的配置，也可以手动修改，修改前请仔细阅读文件中的说明。

UserFunctionsAuto.txt.bak
UserFunctionsAuto.txt 的上一次备份，如果发现最新版本有问题请手动恢复。

Skins
皮肤目录，皮肤名为该目录下 ini 文件的文件名（不含 .ini）。

SearchFileList.txt
搜索到的文件列表，不要手动修改此文件，会被覆盖。

UserFileList.txt
用户自己添加的待搜索文件列表，也是简单模式“发送到”菜单使用的文件列表。
